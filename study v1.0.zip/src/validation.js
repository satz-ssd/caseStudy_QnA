// const [departmentError, setdepartmentError] = useState("");
  // const [clientNameError, setclientNameError] = useState("");
  // const [technologyError, settechnologyError] = useState("");
  // const [questionError, setquestionError] = useState("");
  // const [difficultyLevelError, setdifficultyLevelError] = useState("");



   // let validateDepartment = () => {
  //   if (primaryInfo.department) {
  //     setdepartmentError("");
  //     return true;
  //   } else {
  //     setdepartmentError("*Please, Choose the Department");
  //     return false;
  //   }
  // };

  // let validateClientName = () => {
  //   if (primaryInfo.clientName) {
  //     let regex = /^[a-zA-Z]{2,30}$/;
  //     if (regex.test(primaryInfo.clientName)) {
  //       setclientNameError("");
  //       return true;
  //     } else {
  //       setclientNameError("*Enter valid Client name, only characters allowed");
  //     }
  //   } else {
  //     setclientNameError("*Client Name is Required");
  //   }
  //   return false;
  // };

  // let validateTechnology = () => {
  //   if (primaryInfo.technology) {
  //     settechnologyError("");
  //     return true;
  //   } else {
  //     settechnologyError("*Please, Choose the technology");
  //     return false;
  //   }
  // };

  // let validateQuestion = () => {
  //   if (singleQuestion.question) {
  //     setquestionError("");
  //     return true;
  //   } else {
  //     setquestionError("*Question cannot be blank");
  //     return false;
  //   }
  // };

  // let validateDifficulty = () => {
  //   if (singleQuestion.difficultyLevel) {
  //     setdifficultyLevelError("");
  //     return true;
  //   } else {
  //     setdifficultyLevelError("*Please, Choose the Difficulty Level");
  //     return false;
  //   }
  // };