import React from "react";
import { Col, Row } from "react-bootstrap";

function FallbackUI() {
  return (
 
    <div className="fallBackUi" style={{marginTop:"20px"}}>
    <img src="assets/fallback.png" />
  </div>
    
  );
}

export default FallbackUI;
